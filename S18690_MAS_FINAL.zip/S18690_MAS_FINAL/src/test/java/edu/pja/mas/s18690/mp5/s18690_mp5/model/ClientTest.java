package edu.pja.mas.s18690.mp5.s18690_mp5.model;

import edu.pja.mas.s18690.mp5.s18690_mp5.exception.ModelValidationException;
import edu.pja.mas.s18690.mp5.s18690_mp5.utils.Password_Hasher;
import org.junit.jupiter.api.Test;

class ClientTest {

    @Test
    void setPhone() throws ModelValidationException {
        Client c = Natural_Person.builder().name("Adam").surname("Kowalski")
                .phone("+48 683 453 222").password("haslo").login("adam").build();
        System.out.println(c.getPassword());
        System.out.println(Password_Hasher.check_password("haslo", c.getPassword()));
    }

    @Test
    void getLogin() {
    }

    @Test
    void getPassword() {
    }

    @Test
    void getPhone() {
    }

    @Test
    void setLogin() {
    }

    @Test
    void setPassword() {
    }

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }
}