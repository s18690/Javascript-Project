package edu.pja.mas.s18690.mp5.s18690_mp5.model;

import edu.pja.mas.s18690.mp5.s18690_mp5.repository.CarRepository;
import edu.pja.mas.s18690.mp5.s18690_mp5.repository.MotorbikeRepository;
import edu.pja.mas.s18690.mp5.s18690_mp5.repository.VehicleRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@DataJpaTest
class VehicleTest {

    @Autowired
    private VehicleRepository vehicleRepository;
    @Autowired
    private CarRepository carRepository;
    @Autowired
    private MotorbikeRepository motorbikeRepository;
    @PersistenceContext
    private EntityManager entityManager;


    @Test
    public void testRequiredDependencies() {
        assertNotNull(vehicleRepository);
        assertNotNull(vehicleRepository);
        assertNotNull(motorbikeRepository);
    }

    @Test
    public void testFetchVehicle() {
        assertEquals(2, vehicleRepository.count());
    }


    @Test
    void testToString() {
        Iterable<Vehicle> all = vehicleRepository.findAll();
        for (Vehicle a : all) {
            System.out.println(a);
        }
        assertEquals("Car(super=Vehicle(VIN=4Y1SL65848Z411439, productionDate=2015-10-08, model=Model(id=1, mark=BMW, model=750d)), mileage=125000)", all.iterator().next().toString());
    }

    @Test
    void getVIN() {
        Iterable<Vehicle> all = vehicleRepository.findAll();
        assertEquals("4Y1SL65848Z411439", all.iterator().next().getVIN());
    }

    @Test
    void getProductionDate() {
        Iterable<Vehicle> all = vehicleRepository.findAll();
        assertEquals(LocalDate.parse("2015-10-08"), all.iterator().next().getProductionDate());

    }

    @Test
    void getModel() {
        Iterable<Vehicle> all = vehicleRepository.findAll();
        assertEquals("750d", all.iterator().next().getModel().getModel());

    }

    @Test
    void getRepairs() {
        Iterable<Vehicle> all = vehicleRepository.findAll();
        assertEquals(1, all.iterator().next().getRepairs().stream().findFirst().get().getId());

    }

    @Test
    void setVIN() {
    }

    @Test
    void setProductionDate() {
    }

    @Test
    void setModel() {
    }

    @Test
    void setRepairs() {
    }


}