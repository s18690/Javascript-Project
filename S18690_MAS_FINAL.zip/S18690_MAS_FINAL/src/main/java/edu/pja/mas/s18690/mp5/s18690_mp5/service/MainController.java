package edu.pja.mas.s18690.mp5.s18690_mp5.service;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MainController implements WebMvcConfigurer {
    // Adds more static views to controlled - those which i dont have to write myself
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/home").setViewName("main_menu");
        registry.addViewController("/").setViewName("main_menu");
        registry.addViewController("/hello").setViewName("main_menu");
        registry.addViewController("/login").setViewName("login");
    }
}
