package edu.pja.mas.s18690.mp5.s18690_mp5.model;

// Specialization of Mechanic - Employee
public enum Specialization {
    CAR, MOTORBIKE
}
