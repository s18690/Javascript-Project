package edu.pja.mas.s18690.mp5.s18690_mp5.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Entity;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;


@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class Car extends Vehicle {

    @NotNull(message = "Car mileage cannot be empty")
    @Min(value = 0, message = "Car mileage has to be greater or equal 0")
    int mileage;
}
