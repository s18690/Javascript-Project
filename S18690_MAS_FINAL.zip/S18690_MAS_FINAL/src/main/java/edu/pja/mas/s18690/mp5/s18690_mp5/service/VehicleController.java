package edu.pja.mas.s18690.mp5.s18690_mp5.service;

import edu.pja.mas.s18690.mp5.s18690_mp5.model.Car;
import edu.pja.mas.s18690.mp5.s18690_mp5.model.Motorbike;
import edu.pja.mas.s18690.mp5.s18690_mp5.model.Vehicle;
import edu.pja.mas.s18690.mp5.s18690_mp5.repository.ModelRepository;
import edu.pja.mas.s18690.mp5.s18690_mp5.repository.VehicleRepository;
import edu.pja.mas.s18690.mp5.s18690_mp5.utils.ControllerTools;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@ComponentScan
public class VehicleController {
    @Autowired
    private VehicleRepository vehicleService;
    @Autowired
    private ModelRepository modelService;


    // Shows new car form
    @RequestMapping("/newCar")
    public String showNewCarPage(Model model) {
        Car car = new Car();
        List<edu.pja.mas.s18690.mp5.s18690_mp5.model.Model> models = modelService.findAllNotMotorbikes();
        models.addAll(modelService.findAllNotUsed());
        model.addAttribute("car", car);
        model.addAttribute("models", models.stream()
                .distinct()
                .collect(Collectors.toList()));
        return "new_car";
    }

    // Shows new motorbike form
    @RequestMapping("/newMotorbike")
    public String showNewMotorbikePage(Model model) {
        Motorbike motorbike = new Motorbike();
        List<edu.pja.mas.s18690.mp5.s18690_mp5.model.Model> models = modelService.findAllNotCars();
        models.addAll(modelService.findAllNotUsed());
        model.addAttribute("motorbike", motorbike);
        model.addAttribute("models", models.stream()
                .distinct()
                .collect(Collectors.toList()));
        return "new_motorbike";
    }

    // Saves car to DB
    @RequestMapping(value = "/saveCar", method = RequestMethod.POST)
    public String saveProduct(@Valid @ModelAttribute("car") Car car, BindingResult bindingResult, Model model) {
        if (bindingResult.hasFieldErrors("VIN") || bindingResult.hasFieldErrors("productionDate") || bindingResult.hasFieldErrors("model") || bindingResult.hasFieldErrors("mileage")) {
            List<edu.pja.mas.s18690.mp5.s18690_mp5.model.Model> models = modelService.findAllNotMotorbikes();
            models.addAll(modelService.findAllNotUsed());
            model.addAttribute("car", car);
            model.addAttribute("models", models.stream()
                    .distinct()
                    .collect(Collectors.toList()));
            return "new_car";
        }

        vehicleService.save(car);
        return "redirect:/vehicleList";
    }

    // Saves motorbike to DB
    @RequestMapping(value = "/saveMotorbike", method = RequestMethod.POST)
    public String saveProduct(@Valid @ModelAttribute("motorbike") Motorbike motorbike, BindingResult bindingResult, Model model) {
        if (bindingResult.hasFieldErrors("VIN") || bindingResult.hasFieldErrors("productionDate") || bindingResult.hasFieldErrors("model") || bindingResult.hasFieldErrors("engine_hours")) {
            List<edu.pja.mas.s18690.mp5.s18690_mp5.model.Model> models = modelService.findAllNotCars();
            models.addAll(modelService.findAllNotUsed());
            model.addAttribute("motorbike", motorbike);
            model.addAttribute("models", models.stream()
                    .distinct()
                    .collect(Collectors.toList()));
            return "new_motorbike";
        }
        vehicleService.save(motorbike);
        return "redirect:/vehicleList";
    }

    // Shows list of vehicles.
    @RequestMapping("/vehicleList")
    public String viewVehicleList(Model model) {
        List<Vehicle> listVehicles = vehicleService.findAllByUser(ControllerTools.getCurrentUser());
        listVehicles.addAll(vehicleService.findAllNotAssignedToRepair());
        model.addAttribute("listVehicles", listVehicles.stream()
                .distinct()
                .collect(Collectors.toList()));

        return "vehicle_list";
    }
}
