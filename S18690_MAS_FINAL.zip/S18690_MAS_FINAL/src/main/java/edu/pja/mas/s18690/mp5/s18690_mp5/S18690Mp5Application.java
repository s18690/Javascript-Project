package edu.pja.mas.s18690.mp5.s18690_mp5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S18690Mp5Application {


    public static void main(String[] args) {


        SpringApplication.run(S18690Mp5Application.class, args);
    }

}
