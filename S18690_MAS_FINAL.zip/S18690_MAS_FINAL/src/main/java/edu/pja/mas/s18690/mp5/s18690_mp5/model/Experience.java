package edu.pja.mas.s18690.mp5.s18690_mp5.model;

// Experience of painter
public enum Experience {
    BEGINNER, EXPERIENCED, EXPERT
}

