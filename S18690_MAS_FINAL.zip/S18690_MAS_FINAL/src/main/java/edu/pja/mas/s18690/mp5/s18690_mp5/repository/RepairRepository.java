package edu.pja.mas.s18690.mp5.s18690_mp5.repository;

import edu.pja.mas.s18690.mp5.s18690_mp5.model.Repair;
import edu.pja.mas.s18690.mp5.s18690_mp5.model.Vehicle;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface RepairRepository extends CrudRepository<Repair, Long> {
    @Query("from Repair as v where v.client.login = :login")
     List<Repair> getRepairByClient(@Param("login") String login);

     List<Repair> getRepairByVehicle(Vehicle vehicle);
     Repair getRepairById(Long id);
}
