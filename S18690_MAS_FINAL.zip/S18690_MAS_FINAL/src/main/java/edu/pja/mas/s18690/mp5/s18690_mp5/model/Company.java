package edu.pja.mas.s18690.mp5.s18690_mp5.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Entity;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class Company extends Client {

    @NotNull
    @NotBlank
    @Pattern(regexp = "'/^[0-9]{10}$/'", flags = Pattern.Flag.UNICODE_CASE)
    private String nip;

    @NotNull
    @NotBlank
    @Pattern(regexp = "'/^[0-9]{10}$/'", flags = Pattern.Flag.UNICODE_CASE)
    private String regon;


    @NotBlank(message = "Name and surname cannot be blank")
    @NotNull(message = "Name and surname cannot be null")
    private String address;

    @NotBlank(message = "Name and surname cannot be blank")
    @NotNull(message = "Name and surname cannot be null")
    @Pattern(regexp = "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\\\.[A-Z]{2,6}$", flags = Pattern.Flag.UNICODE_CASE)
    private String email;
}
