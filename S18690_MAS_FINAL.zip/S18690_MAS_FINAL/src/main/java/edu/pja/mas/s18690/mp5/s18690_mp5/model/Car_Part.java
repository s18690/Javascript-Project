package edu.pja.mas.s18690.mp5.s18690_mp5.model;

import lombok.*;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.HashSet;
import java.util.Set;


@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class Car_Part {

    @Id
    @NotBlank
    private String part_number;

    @NotBlank
    private String name, manufacturer;

    @NotNull
    @Min(0)
    private double buy_price;

    @NotNull
    private double sell_price;

    public double get_Profit() {
        return sell_price - buy_price;
    }

    // Connection to model class
    @ManyToMany
    @Builder.Default
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    Set<Model> models = new HashSet<>();

}
