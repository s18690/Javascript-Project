package edu.pja.mas.s18690.mp5.s18690_mp5.repository;

import edu.pja.mas.s18690.mp5.s18690_mp5.model.Client;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface ClientRepository extends CrudRepository<Client, Long> {
    Client findByLogin(@Param("login") String login);
}
