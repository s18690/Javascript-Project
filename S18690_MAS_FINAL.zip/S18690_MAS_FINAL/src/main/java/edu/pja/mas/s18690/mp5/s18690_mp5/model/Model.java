package edu.pja.mas.s18690.mp5.s18690_mp5.model;

import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@SuperBuilder
@NoArgsConstructor

@AllArgsConstructor
public class Model {

    @Id
    @NotNull(message = "Model cannot be empty")
    @EqualsAndHashCode.Exclude
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotBlank(message = "Mark cannot be empty")
    @NotNull(message = "Mark cannot be empty")
    @Size(min = 2, max = 255, message = "Mark length should be between 2 and 255 characters")
    private String mark;

    @NotBlank(message = "Model cannot be empty")
    @NotNull(message = "Model cannot be empty")
    @Size(min = 2, max = 255, message = "Model length should be between 2 and 255 characters")
    private String model;

    // Connection with vehicles
    @OneToMany(mappedBy = "model", cascade = CascadeType.REMOVE)
    @Builder.Default
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private Set<Vehicle> vehicles = new HashSet<>();

    // Connection with models ( many - many)
    @ManyToMany(mappedBy = "models")
    @Builder.Default
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    Set<Car_Part> car_parts = new HashSet<>();
}
