package edu.pja.mas.s18690.mp5.s18690_mp5.model;

public enum Employee_Type {
    MECHANIC, PAINTER, MANAGER
}
