package edu.pja.mas.s18690.mp5.s18690_mp5.repository;

import edu.pja.mas.s18690.mp5.s18690_mp5.model.Model;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ModelRepository extends CrudRepository<Model, Long> {

    @Query(" from Model as m left outer join fetch m.vehicles as v where v.VIN not in (SELECT VIN FROM Motorbike)")
    List<Model> findAllNotMotorbikes();

    @Query("from Model as m left outer join fetch m.vehicles as v where v.VIN not in (SELECT VIN FROM Car)")
    List<Model> findAllNotCars();

    @Query("from Model as m where m.vehicles.size=0")
    List<Model> findAllNotUsed();
}
