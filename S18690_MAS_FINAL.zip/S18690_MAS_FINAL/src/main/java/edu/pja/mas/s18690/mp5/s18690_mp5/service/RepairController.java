package edu.pja.mas.s18690.mp5.s18690_mp5.service;

import edu.pja.mas.s18690.mp5.s18690_mp5.model.Repair;
import edu.pja.mas.s18690.mp5.s18690_mp5.model.Repair_State;
import edu.pja.mas.s18690.mp5.s18690_mp5.model.Vehicle;
import edu.pja.mas.s18690.mp5.s18690_mp5.repository.ClientRepository;
import edu.pja.mas.s18690.mp5.s18690_mp5.repository.OpinionRepository;
import edu.pja.mas.s18690.mp5.s18690_mp5.repository.RepairRepository;
import edu.pja.mas.s18690.mp5.s18690_mp5.repository.VehicleRepository;
import edu.pja.mas.s18690.mp5.s18690_mp5.utils.ControllerTools;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
@ComponentScan
public class RepairController {
    @Autowired
    private VehicleRepository vehicleService;
    @Autowired
    private RepairRepository repairService;
    @Autowired
    private ClientRepository clientService;
    @Autowired
    private OpinionRepository opinionRepository;

    //Shows list of list.
    @RequestMapping("/repairList")
    public String viewRepairList(Model model) {
        Iterable<Repair> listRepair = repairService.getRepairByClient(ControllerTools.getCurrentUser());
        model.addAttribute("listRepairs", listRepair);

        return "repair_list";
    }

    // Saves new repair model form
    @RequestMapping("/newRepair")
    public String showNewRepairPage(Model model) {
        Repair repair = new Repair();
        List<Vehicle> vehicles = vehicleService.findAllByUser(ControllerTools.getCurrentUser());
        vehicles.addAll(vehicleService.findAllNotAssignedToRepair());
        model.addAttribute("vehicles", vehicles.stream()
                .distinct()
                .collect(Collectors.toList()));
        model.addAttribute("repair", repair);
        return "new_repair";
    }

    // Saves new repair to DB
    @RequestMapping(value = "/saveRepair", method = RequestMethod.POST)
    public String saveRepair(@Valid @ModelAttribute("repair") Repair repair, BindingResult bindingResult, Model model) {
        if (bindingResult.hasFieldErrors("startDate") || bindingResult.hasFieldErrors("vehicle")) {
            List<Vehicle> vehicles = vehicleService.findAllByUser(ControllerTools.getCurrentUser());
            vehicles.addAll(vehicleService.findAllNotAssignedToRepair());
            model.addAttribute("repair", repair);
            model.addAttribute("vehicles", vehicles);
            return "new_repair";
        }
        repair.setRepair_state(Repair_State.BOOKED);
        repair.setClient(clientService.findByLogin(ControllerTools.getCurrentUser()));
        repairService.save(repair);
        return "redirect:/repairList";

    }

    @RequestMapping(value = "/updateRepair/{id}", method = RequestMethod.POST)
    public String updateRepair(@Valid @ModelAttribute("repair") Repair repair, BindingResult bindingResult, Model model, @PathVariable(name = "id") Long id) {
        if (bindingResult.hasFieldErrors("startDate") || bindingResult.hasFieldErrors("vehicle")) {
            List<Vehicle> vehicles = vehicleService.findAllByUser(ControllerTools.getCurrentUser());
            vehicles.addAll(vehicleService.findAllNotAssignedToRepair());
            model.addAttribute("repair", repair);
            model.addAttribute("vehicles", vehicles);
            return "new_repair";
        }
        Optional<Repair> optionalRep = repairService.findById(id);
        if (optionalRep.isEmpty()) return "redirect:/repairList";
        Repair rep = optionalRep.get();
        rep.setVehicle(repair.getVehicle());
        rep.setStartDate(repair.getStartDate());
        repair.setClient(clientService.findByLogin(ControllerTools.getCurrentUser()));
        repairService.save(rep);

        return "redirect:/repairList";

    }


    @RequestMapping("/repairListForSpecifiedVehicle/{id}")
    public ModelAndView showSpecifiedRepairsList(@PathVariable(name = "id") Long id) {
        // Check that proper user want to see a list.
        if (vehicleService.findAllByUser(ControllerTools.getCurrentUser()).stream().noneMatch(e -> e.getId().equals(id)))
            return new ModelAndView("redirect:/vehicleList");

        ModelAndView mav = new ModelAndView("specified_vehicle_repairs");
        List<Repair> repairs = repairService.getRepairByVehicle(vehicleService.getById(id));
        mav.addObject("listRepairs", repairs);
        return mav;
    }

    @RequestMapping("/editRepair/{id}")
    public ModelAndView showEditRepairPage(@PathVariable(name = "id") Long id) {
        Repair repair = repairService.getRepairById(id);
        // Check that proper user want to see a list.
        if (repairService.getRepairByClient(ControllerTools.getCurrentUser()).stream().noneMatch(e -> e.getId().equals(id)) || repair.getRepair_state() != Repair_State.BOOKED)
            return new ModelAndView("redirect:/repairList");
        ModelAndView mav = new ModelAndView("edit_repair");
        List<Vehicle> vehicles = vehicleService.findAllByUser(ControllerTools.getCurrentUser());
        vehicles.addAll(vehicleService.findAllNotAssignedToRepair());
        mav.addObject("vehicles", vehicles.stream()
                .distinct()
                .collect(Collectors.toList()));
        mav.addObject("repair", repair);
        return mav;
    }


}
