package edu.pja.mas.s18690.mp5.s18690_mp5.exception;

public class ModelValidationException extends Exception {
    public ModelValidationException(String message) {
        super(message);
    }
}
