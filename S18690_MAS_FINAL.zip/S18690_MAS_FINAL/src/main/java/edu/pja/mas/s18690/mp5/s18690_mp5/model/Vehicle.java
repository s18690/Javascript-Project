package edu.pja.mas.s18690.mp5.s18690_mp5.model;


import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public abstract class Vehicle {


    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @NotNull(message = "ID CANNOT BE NULL")
    private Long id;


    @NotNull(message = "VIN number cannot be empty.")
    @NotBlank(message = "VIN number cannot be empty.")
    @Pattern(regexp = "\\b[(A-H|J-N|P|R-Z|0-9)]{17}\\b", flags = Pattern.Flag.UNICODE_CASE, message = "VIN number must have:\n 17 characters,\n capital letters and numbers only")
    private String VIN;


    @NotNull(message = "Production date cannot be null")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate productionDate;

    //Connection with model
    @ManyToOne
    @NotNull(message = "Model cannot be empty ")
    private Model model;

    // Connection with repairs
    @OneToMany(mappedBy = "vehicle", fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REFRESH})
    @Builder.Default
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private Set<Repair> repairs = new HashSet<>();


}
