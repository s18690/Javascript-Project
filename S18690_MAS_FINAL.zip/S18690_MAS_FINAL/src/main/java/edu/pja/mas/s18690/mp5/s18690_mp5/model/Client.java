package edu.pja.mas.s18690.mp5.s18690_mp5.model;

import edu.pja.mas.s18690.mp5.s18690_mp5.exception.ModelValidationException;
import edu.pja.mas.s18690.mp5.s18690_mp5.utils.Password_Hasher;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class Client {
    @Id
    @NotNull
    @NotBlank
    private String login;

    @NotNull
    @NotBlank
    private String password;

    @NotNull
    @NotBlank
    @Pattern(regexp = "^([+]?[\\s0-9]+)?(\\d{3}|[(]?[0-9]+[)])?([-]?[\\s]?[0-9])+$", flags = Pattern.Flag.UNICODE_CASE)
    private String phone;

    // Connection to repair class.
    @OneToMany(mappedBy = "client")
    @Builder.Default
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private Set<Repair> repairs = new HashSet<>();

    // Password setter which holds needed regex and hashing function.
    // That was necessary to move checking here because else program will check regex for already hashed password
    public void setPassword(String password) throws ModelValidationException {
        if (password == null || password.isBlank())
            throw new ModelValidationException("Password cannot be null or blank");
        if (!password.matches("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{12,}$"))
            throw new ModelValidationException("Password has to contain:\n 12 signs\n at least one small letter\n at least one small letter\n at least one special character \n at least one number");
        this.password = Password_Hasher.hash_password(password);
    }

    // Override of ClientBuilder to get custom password method in builder - with hashing and constraints
    public abstract static class ClientBuilder<C extends Client, B extends ClientBuilder<C, B>> {
        public ClientBuilder<C, B> password(String password) throws ModelValidationException {
            if (password == null || password.isBlank())
                throw new ModelValidationException("Password cannot be null or blank");
            this.password = Password_Hasher.hash_password(password);
            return this;
        }
    }

}



