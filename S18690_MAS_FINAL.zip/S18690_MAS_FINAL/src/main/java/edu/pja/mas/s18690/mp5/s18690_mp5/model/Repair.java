package edu.pja.mas.s18690.mp5.s18690_mp5.model;

import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class Repair {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @NotNull(message = "ID cannot be null")
    private Long id;

    @NotNull(message = "Start date cannot be empty")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate startDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate EndDate;

    @NotNull
    @Enumerated
    private Repair_State repair_state;

    // Connection with vehicle
    @ManyToOne
    @ToString.Exclude
    @NotNull(message = "Vehicle cannot be empty")
    @EqualsAndHashCode.Exclude
    private Vehicle vehicle;

    // Connection with client
    @ManyToOne
    @ToString.Exclude
    @NotNull(message = "Client cannot be empty")
    @EqualsAndHashCode.Exclude
    private Client client;

    // Connection with Opinion - composition 0..1-1
    @OneToOne(cascade = CascadeType.REMOVE)
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private Opinion opinion;

    // many- many connection with repairs
    @ManyToMany(mappedBy = "repairs")
    @Builder.Default
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    Set<Employee> employees = new HashSet<>();

    public Optional<LocalDate> getEndDate(){
        return Optional.ofNullable(EndDate);
    }

    public Optional<Opinion> getOpinion(){
        return Optional.ofNullable(opinion);
    }

}
