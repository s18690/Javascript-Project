package edu.pja.mas.s18690.mp5.s18690_mp5.security;

import edu.pja.mas.s18690.mp5.s18690_mp5.model.Client;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;

// this class is responsible for handling usernames and password in proper way for our application.
// Currently configured for testing - do not use for production
public class MyUserPrincipal implements UserDetails {
    private final Client user;

    public MyUserPrincipal(Client user) {
        this.user = user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null;
    }

    @Override
    public String getPassword() {
        return user.getPassword();
    }

    @Override
    public String getUsername() {
        return user.getLogin();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}

