package edu.pja.mas.s18690.mp5.s18690_mp5.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Entity;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class Natural_Person extends Client {

    @NotBlank(message = "Name and surname cannot be blank")
    @NotNull(message = "Name and surname cannot be null")
    private String name, surname;


}
