package edu.pja.mas.s18690.mp5.s18690_mp5.model;

import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.Entity;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true, includeFieldNames = true)
public class Motorbike extends Vehicle {

    @NotNull(message = "Motorbike engine hours cannot be empty")
    @Min(value = 0, message = "Motorbike engine hours has to be greater or equal 0")
    int engine_hours;
}
