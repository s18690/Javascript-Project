package edu.pja.mas.s18690.mp5.s18690_mp5.repository;

import edu.pja.mas.s18690.mp5.s18690_mp5.model.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface VehicleRepository extends JpaRepository<Vehicle, Long> {

    // Finds vehicle with production dates between min and max date.
    @Query("from Vehicle as v where v.productionDate between :minDate and :maxDate")
    List<Vehicle> findByProductionDateBetween(@Param("minDate") LocalDate minDate, @Param("maxDate") LocalDate maxDate);

    // Finds vehicles which are assigned to user String user.
    @Query("from Vehicle as v left outer join fetch v.repairs as r left outer join fetch r.client as c where c.login = :login")
    List<Vehicle> findAllByUser(@Param("login") String login);

    // Finds vehicles which are assigned to any repair.
    @Query("from Vehicle as v where v.VIN not in (SELECT r.vehicle.VIN FROM Repair as r)")
    List<Vehicle> findAllNotAssignedToRepair();
}

