package edu.pja.mas.s18690.mp5.s18690_mp5.repository;


import edu.pja.mas.s18690.mp5.s18690_mp5.model.Vehicle;
import org.springframework.data.repository.CrudRepository;

public interface MotorbikeRepository extends CrudRepository<Vehicle, Long> {
}
