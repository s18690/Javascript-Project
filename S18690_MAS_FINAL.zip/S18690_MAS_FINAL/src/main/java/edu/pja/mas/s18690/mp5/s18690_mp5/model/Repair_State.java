package edu.pja.mas.s18690.mp5.s18690_mp5.model;

// Possible states of repairs
public enum Repair_State {
    BOOKED,
    CANCELLED,
    CONFIRMED,
    IN_PROGRESS,
    PAID,
    FINISHED
}
