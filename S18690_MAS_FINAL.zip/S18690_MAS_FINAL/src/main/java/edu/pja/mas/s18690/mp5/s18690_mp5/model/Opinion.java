package edu.pja.mas.s18690.mp5.s18690_mp5.model;

import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor

public class Opinion {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @NotNull
    private Long id;

    @NotNull
    @Min(0)
    @Max(5)
    private int rating;

    @NotNull
    private String opinion_text;

    //Connection with repair
    @OneToOne
    @ToString.Exclude
    @NotNull
    @EqualsAndHashCode.Exclude
    Repair repair;
}
