package edu.pja.mas.s18690.mp5.s18690_mp5.utils;

import org.springframework.security.crypto.scrypt.SCryptPasswordEncoder;

// Simple class that implements hashing algorithm
public abstract class Password_Hasher {

    public static String hash_password(String password) {
        return new SCryptPasswordEncoder().encode(password);
    }

    public static boolean check_password(String password, String hash) {
        return new SCryptPasswordEncoder().matches(password, hash);
    }

}
