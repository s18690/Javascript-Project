package edu.pja.mas.s18690.mp5.s18690_mp5.service;

import edu.pja.mas.s18690.mp5.s18690_mp5.repository.ModelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

@Controller
@ComponentScan
public class ModelController {
    @Autowired
    private ModelRepository modelService;

    // Saves new vehicle model form
    @RequestMapping("/newModel")
    public String showNewModelPage(Model model) {
        edu.pja.mas.s18690.mp5.s18690_mp5.model.Model modell = new edu.pja.mas.s18690.mp5.s18690_mp5.model.Model();
        model.addAttribute("modell", modell);
        return "new_model";
    }

    // Saves new vehicle model to DB
    @RequestMapping(value = "/saveModel", method = RequestMethod.POST)
    public String saveProduct(@Valid @ModelAttribute("modell") edu.pja.mas.s18690.mp5.s18690_mp5.model.Model modell, BindingResult bindingResult, Model model) {
        if (bindingResult.hasFieldErrors("mark") || bindingResult.hasFieldErrors("model")) return "new_model";
        modelService.save(modell);
        return "redirect:/modelList";
    }

    // Shows list of models.
    @RequestMapping("/modelList")
    public String viewModelList(Model model) {
        Iterable<edu.pja.mas.s18690.mp5.s18690_mp5.model.Model> listProducts = modelService.findAll();
        model.addAttribute("listModels", listProducts);
        return "model_list";
    }
}
