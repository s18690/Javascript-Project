package edu.pja.mas.s18690.mp5.s18690_mp5.model;

import edu.pja.mas.s18690.mp5.s18690_mp5.exception.ModelValidationException;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Entity
@Data
@SuperBuilder
@NoArgsConstructor
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @NotNull
    private Long id;

    @NotBlank(message = "Name and surname cannot be blank")
    @NotNull(message = "Name and surname cannot be null")
    private String name, surname;

    @NotNull(message = "Date of employment date cannot be null")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate date_of_employment;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate date_of_firing;

    @NotNull
    @Min(2800)
    private double salary;

    // Collection of enums - types of worker must be stored as separate table
    @ElementCollection(fetch = FetchType.LAZY)
    @Enumerated(EnumType.STRING)
    @CollectionTable(name = "Employee_Type"
            , joinColumns = @JoinColumn(name = "employee_id"))
    @Column(name = "Employee_Type", nullable = false)
    private Set<Employee_Type> types;

    private Specialization specialization;
    private Experience experience;

    // Collection of sets - must be stored in separate table.
    @ElementCollection
    @CollectionTable(name = "Known_language"
            , joinColumns = @JoinColumn(name = "employee_id"))
    @Column(name = "Known_language")
    private Set<String> known_languages;

    public Optional<LocalDate> getDate_of_firing() {
        return Optional.ofNullable(date_of_firing);
    }
    public Optional<Specialization> getSpecialization() {
        return Optional.ofNullable(specialization);
    }
    public Optional<Experience> getExperience() {
        return Optional.ofNullable(experience);
    }

    // Many to many relation with repairs
    @ManyToMany
    @Builder.Default
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @JoinTable
    Set<Repair> repairs = new HashSet<>();

    // Checkers
    public boolean isManager() {
        return this.types.contains(Employee_Type.MANAGER);
    }

    public boolean isPainter() {
        return this.types.contains(Employee_Type.PAINTER);
    }

    public boolean isMechanic() {
        return this.types.contains(Employee_Type.MECHANIC);
    }

    // Overrided builder method to ensure that each worker will have only allowed for him fields
    public abstract static class EmployeeBuilder<C extends Employee, B extends Employee.EmployeeBuilder<C, B>> {
        public Employee.EmployeeBuilder<C, B> specialization(Specialization specialization) throws ModelValidationException {
            if (specialization == null) throw new ModelValidationException("specialization cannot be null or blank");
            if (!this.build().isMechanic())
                throw new ModelValidationException("Employee is not mechanic so he cannot have specialization");
            this.specialization = specialization;
            return this;
        }

        public Employee.EmployeeBuilder<C, B> experience(Experience experience) throws ModelValidationException {
            if (experience == null) throw new ModelValidationException("specialization cannot be null or blank");
            if (!this.build().isPainter())
                throw new ModelValidationException("Employee is not painter so he cannot have experience");
            this.experience = experience;
            return this;
        }

        public Employee.EmployeeBuilder<C, B> known_languages(Set<String> known_languages) throws ModelValidationException {
            if (known_languages == null) throw new ModelValidationException("specialization cannot be null or blank");
            if (!this.build().isManager())
                throw new ModelValidationException("Employee is not Manager so he cannot have known languages");
            this.known_languages = known_languages;
            return this;
        }
    }

}
