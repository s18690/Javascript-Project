package edu.pja.mas.s18690.mp5.s18690_mp5.security;

import edu.pja.mas.s18690.mp5.s18690_mp5.model.Client;
import edu.pja.mas.s18690.mp5.s18690_mp5.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

//This class was created to properly handle users that are logged in. (check that they are logged or not)
@Service
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    private ClientRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) {
        Client user = userRepository.findByLogin(username);
        if (user == null) {
            throw new UsernameNotFoundException(username);
        }
        return new MyUserPrincipal(user);
    }
}