package edu.pja.mas.s18690.mp5.s18690_mp5.repository;

import edu.pja.mas.s18690.mp5.s18690_mp5.model.Opinion;
import org.springframework.data.repository.CrudRepository;

public interface OpinionRepository extends CrudRepository<Opinion, Long> {
}
